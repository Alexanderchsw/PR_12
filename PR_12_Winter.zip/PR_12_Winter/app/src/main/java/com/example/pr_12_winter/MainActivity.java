package com.example.pr_12_winter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    String firstnumber;
    String operator;
    Boolean isnew=true;
    EditText editText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText=findViewById(R.id.editText);
    }
    public void clickNumber(View view){
        if(isnew)
            editText.setText("");
        isnew=false;
        String number=editText.getText().toString();
        switch(view.getId()){
            case R.id.btn1:number=number+"1";break;
            case R.id.btn2:number=number+"2";break;
            case R.id.btn3:number=number+"3";break;
            case R.id.btn4:number=number+"4";break;
            case R.id.btn5:number=number+"5";break;
            case R.id.btn6:number=number+"6";break;
            case R.id.btn7:number=number+"7";break;
            case R.id.btn8:number=number+"8";break;
            case R.id.btn9:number=number+"9";break;
            case R.id.btnNull:number=number+"0";break;
            case R.id.btnPlusMinus:
                if(minusPresent(number)){

                }else {
                    number="-"+number;
                }
                break;
            case R.id.btnPoint:
                if(pointPresent(number)){

                }else{
                    number=number+"-";
                }
                break;

        }
        editText.setText(number);
    }
    public boolean minusPresent(String number){
        if(number.indexOf("-")==-1){
            return false;
        }else{
            return true;
        }
    }
    public boolean pointPresent(String number){

        if(number.indexOf(".")==-1){
            return false;
        }else{
            return true;
        }
    }
    public void operation(View view){
        isnew=true;
        firstnumber=editText.getText().toString();

        switch (view.getId()){
            case R.id.btnMinus: operator="-";break;
            case R.id.btnPlus: operator="+";break;
            case R.id.btnDevide: operator="/";break;
            case R.id.btnMultiply: operator="*";break;
        }
    }
    public void clickEqualle(View view){
        String secondnumber = editText.getText().toString();
        Double result=0.0;
        switch(operator){
            case "-": result = Double.parseDouble(firstnumber)-Double.parseDouble(secondnumber);break;
            case "+": result = Double.parseDouble(firstnumber)+Double.parseDouble(secondnumber);break;
            case "/": result = Double.parseDouble(firstnumber)/Double.parseDouble(secondnumber);break;
            case "*": result = Double.parseDouble(firstnumber)*Double.parseDouble(secondnumber);break;

        }
        editText.setText(result + "");
    }
    public void acClick(View view){
        editText.setText("0");
        isnew=true;
    }
}